package serv_1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jdk.nashorn.internal.parser.JSONParser;
/**
 * Servlet implementation class homepage
 */
@WebServlet("/homepage")
public class homepage extends HttpServlet {
	JSONParser par= new JSONParser(null, null, false);
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public homepage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String src=request.getParameter("src_stat");
		String dest=request.getParameter("dest_stat");
		//out.println("Invalid Username and/or Password" );
		/*for(String s: par.)
		{
			if(par..equalsIgnoreCase(src) && par..equalsIgnoreCase(dest)){
				RequestDispatcher rd = request.getRequestDispatcher("/conf.html");
				rd.forward(request,response);
			}else{
				RequestDispatcher rd = request.getRequestDispatcher("/home.html");
				rd.include(request, response);
				out.println("Invalid Source and/or Destination" );
			}
		}*/ //write a for loop to compare data in json file to the input
		//write a function above to read json file and allow user to book ticket if ticket avaiable are non-zero.
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
